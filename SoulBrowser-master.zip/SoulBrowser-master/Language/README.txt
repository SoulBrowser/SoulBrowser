Please correct the wrong translation yourself or email the corrected file.
Thank you.


⭐ Language

Reference 1 : values-ko  Korean
Reference 2 : values     English

values-de        German
values-es        Spanish
values-fr        French
values-in        Indonesia
values-it        Italian
values-ja        Japanese
values-ko        Korean
values-pl        Poland
values-pt        Portuguese
values-ro        Romania
values-ru        Russian
values-th        Thai
values-tr        Turkey
values-vi        Vietnamese
values-zh-rCN    Chinese Simplified
values-zh-rTW    Chinese Traditional
values           English


⭐ Code definition

&#160; : First space
&#8230; : ... (3 dots)
&#60; : <
&#62; : >
\n : New line
%s : Variable text
%d : Variable number

ex)
<string name="item">&#160;item</string>
<string name="loading">Loading&#8230;</string>
<string name="exit_noti_1">&#60; Clear on exit &#62;\n%s deleted.</string>
<string name="file_added">%d files added</string>
